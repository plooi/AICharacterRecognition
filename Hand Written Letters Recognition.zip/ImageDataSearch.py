"""
DATASET: Use emnist-balanced

"""


from __future__ import print_function
import os, sys
from PIL import Image
import scipy.io
import re
import sys
def get_mapping(mapping_file):
    mapping = {}
    f = open(mapping_file)
    for line in f:
        line =  line.strip().split(" ")
        mapping[int(line[0])] = chr(int(line[1]))
  
    return mapping
def get_data(file_name, iterator, mapping_file):
    if mapping_file == None:
        class NoMapping:
            def __getitem__(self, key):
                return key
        mapping = NoMapping()
    else:
        mapping = get_mapping(mapping_file)
    
    data = []
    f = open(file_name, 'r')
    p = re.compile(',')
    lines = f.readlines()
    for i in iterator:
        l = lines[i]
        #Daniel's code
        example = [int(x) for x in p.split(l.strip())]
        pixels = example[1:]
        letter = example[0]
        size = 25,25
        img = Image.new('L', (28, 28))
        img.putdata(pixels)
        img.thumbnail(size, Image.ANTIALIAS)
        ###
        
        img = img.rotate(-90)
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        
        data.append({"label" : str(mapping[letter]), "image" : img})
    return data
def show(data_array, index):
    data_array[index]["image"].show()
def show2(file_name, index):
    show(get_data(file_name, [index], None), 0)
    
def main():
    data = get_data("emnist-letters-train.csv", range(0,100), "emnist-letters-mapping.txt")
    

 
if __name__ == "__main__":
  main()
